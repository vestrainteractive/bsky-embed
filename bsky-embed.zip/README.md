# bsky-embed
embed your bluesky posts in a wp widget

To use:

1. Plop the bsky-widget.php file in your plugins folder and activate.
2. appearance > widgets and set the widget on the appropriate sidebar
3. fill out the widget form and press save.
4. enjoy

New in version 1.1:  Shortcode and dark mode support!
[bsky_embed username="vestrainteractive.com" limit="4" height="150" mode="dark"]

Version 1.1 and later does not need the truncate.js file.  We have left it here for legacy reasons.  In the final release zip, it will not be included.
You will likely need to style the output using CSS.



Inspired by DavidC @twowheelsin.com
